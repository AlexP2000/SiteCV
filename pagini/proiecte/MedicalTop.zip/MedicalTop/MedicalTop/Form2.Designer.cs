﻿
namespace MedicalTop
{
    partial class Ecografie_abdominala
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Ecografie_abdominala));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Pacient = new System.Windows.Forms.TextBox();
            this.Data = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Nr = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Vena_splenica_dimensiuni = new System.Windows.Forms.TextBox();
            this.Observatii2 = new System.Windows.Forms.TextBox();
            this.Pereti_antrali = new System.Windows.Forms.TextBox();
            this.Observatii1 = new System.Windows.Forms.TextBox();
            this.Dimensiuni1 = new System.Windows.Forms.TextBox();
            this.Dadls = new System.Windows.Forms.TextBox();
            this.Colecist = new System.Windows.Forms.TextBox();
            this.Pancreas_cu_ecostructura = new System.Windows.Forms.TextBox();
            this.Ficat_cu_ecostructura = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.Observatii6 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Rinichi_stang_ip = new System.Windows.Forms.TextBox();
            this.Rinichi_stang_diametru = new System.Windows.Forms.TextBox();
            this.Splina_ecostructura = new System.Windows.Forms.ComboBox();
            this.Concluzii = new System.Windows.Forms.TextBox();
            this.Vezica_urinara_dimensiuni = new System.Windows.Forms.TextBox();
            this.UtersauProstata = new System.Windows.Forms.TextBox();
            this.Observatii5 = new System.Windows.Forms.TextBox();
            this.Observatii4 = new System.Windows.Forms.TextBox();
            this.Rinichi_drept_ip = new System.Windows.Forms.TextBox();
            this.Rinichi_drep_diametru = new System.Windows.Forms.TextBox();
            this.Splina_dimensiuni = new System.Windows.Forms.TextBox();
            this.Observatii3 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.Genereaza_pdf = new System.Windows.Forms.Button();
            this.VP = new System.Windows.Forms.TextBox();
            this.CBP = new System.Windows.Forms.TextBox();
            this.Dapld = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(836, 366);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Pacient
            // 
            this.Pacient.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pacient.Location = new System.Drawing.Point(1019, 233);
            this.Pacient.Name = "Pacient";
            this.Pacient.Size = new System.Drawing.Size(362, 34);
            this.Pacient.TabIndex = 14;
            // 
            // Data
            // 
            this.Data.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Data.Location = new System.Drawing.Point(1511, 233);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(220, 34);
            this.Data.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1412, 235);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 33);
            this.label4.TabIndex = 12;
            this.label4.Text = "Data:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(897, 235);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 33);
            this.label3.TabIndex = 11;
            this.label3.Text = "Pacient:";
            // 
            // Nr
            // 
            this.Nr.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nr.Location = new System.Drawing.Point(1422, 125);
            this.Nr.Name = "Nr";
            this.Nr.Size = new System.Drawing.Size(100, 34);
            this.Nr.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1364, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 33);
            this.label2.TabIndex = 9;
            this.label2.Text = "Nr:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1091, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 33);
            this.label1.TabIndex = 8;
            this.label1.Text = "Ecografie abdominala";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(51, 637);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(77, 33);
            this.label26.TabIndex = 103;
            this.label26.Text = "CBP:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(51, 598);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 33);
            this.label9.TabIndex = 102;
            this.label9.Text = "VP:";
            // 
            // Vena_splenica_dimensiuni
            // 
            this.Vena_splenica_dimensiuni.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vena_splenica_dimensiuni.Location = new System.Drawing.Point(394, 889);
            this.Vena_splenica_dimensiuni.Name = "Vena_splenica_dimensiuni";
            this.Vena_splenica_dimensiuni.Size = new System.Drawing.Size(124, 39);
            this.Vena_splenica_dimensiuni.TabIndex = 101;
            // 
            // Observatii2
            // 
            this.Observatii2.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Observatii2.Location = new System.Drawing.Point(220, 849);
            this.Observatii2.Multiline = true;
            this.Observatii2.Name = "Observatii2";
            this.Observatii2.Size = new System.Drawing.Size(614, 34);
            this.Observatii2.TabIndex = 100;
            // 
            // Pereti_antrali
            // 
            this.Pereti_antrali.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pereti_antrali.Location = new System.Drawing.Point(265, 804);
            this.Pereti_antrali.Name = "Pereti_antrali";
            this.Pereti_antrali.Size = new System.Drawing.Size(127, 39);
            this.Pereti_antrali.TabIndex = 99;
            // 
            // Observatii1
            // 
            this.Observatii1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Observatii1.Location = new System.Drawing.Point(220, 763);
            this.Observatii1.Multiline = true;
            this.Observatii1.Name = "Observatii1";
            this.Observatii1.Size = new System.Drawing.Size(614, 34);
            this.Observatii1.TabIndex = 98;
            // 
            // Dimensiuni1
            // 
            this.Dimensiuni1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dimensiuni1.Location = new System.Drawing.Point(243, 718);
            this.Dimensiuni1.Name = "Dimensiuni1";
            this.Dimensiuni1.Size = new System.Drawing.Size(127, 39);
            this.Dimensiuni1.TabIndex = 97;
            // 
            // Dadls
            // 
            this.Dadls.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dadls.Location = new System.Drawing.Point(160, 443);
            this.Dadls.Multiline = true;
            this.Dadls.Name = "Dadls";
            this.Dadls.Size = new System.Drawing.Size(388, 35);
            this.Dadls.TabIndex = 95;
            // 
            // Colecist
            // 
            this.Colecist.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Colecist.Location = new System.Drawing.Point(200, 551);
            this.Colecist.Multiline = true;
            this.Colecist.Name = "Colecist";
            this.Colecist.Size = new System.Drawing.Size(634, 33);
            this.Colecist.TabIndex = 94;
            // 
            // Pancreas_cu_ecostructura
            // 
            this.Pancreas_cu_ecostructura.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pancreas_cu_ecostructura.Location = new System.Drawing.Point(387, 683);
            this.Pancreas_cu_ecostructura.Multiline = true;
            this.Pancreas_cu_ecostructura.Name = "Pancreas_cu_ecostructura";
            this.Pancreas_cu_ecostructura.Size = new System.Drawing.Size(447, 28);
            this.Pancreas_cu_ecostructura.TabIndex = 93;
            // 
            // Ficat_cu_ecostructura
            // 
            this.Ficat_cu_ecostructura.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ficat_cu_ecostructura.Location = new System.Drawing.Point(302, 388);
            this.Ficat_cu_ecostructura.Multiline = true;
            this.Ficat_cu_ecostructura.Name = "Ficat_cu_ecostructura";
            this.Ficat_cu_ecostructura.Size = new System.Drawing.Size(532, 31);
            this.Ficat_cu_ecostructura.TabIndex = 92;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(44, 851);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(137, 33);
            this.label17.TabIndex = 91;
            this.label17.Text = "Observatii:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(44, 891);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(313, 33);
            this.label16.TabIndex = 88;
            this.label16.Text = "Vena splenica:Dimensiuni:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(44, 804);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(166, 33);
            this.label14.TabIndex = 86;
            this.label14.Text = "Pereti antrali:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(46, 763);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(137, 33);
            this.label13.TabIndex = 85;
            this.label13.Text = "Observatii:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(45, 718);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(152, 33);
            this.label24.TabIndex = 82;
            this.label24.Text = "Dimensiuni:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(45, 679);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(296, 33);
            this.label8.TabIndex = 81;
            this.label8.Text = "Pancreas cu ecostructura:";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(45, 548);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(115, 33);
            this.label.TabIndex = 80;
            this.label.Text = "Colecist:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(45, 503);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 33);
            this.label7.TabIndex = 79;
            this.label7.Text = "Dapld:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(46, 445);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 33);
            this.label6.TabIndex = 78;
            this.label6.Text = "Dadls:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(44, 386);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(254, 33);
            this.label5.TabIndex = 77;
            this.label5.Text = "Ficat cu ecostructura:";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(1146, 849);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(585, 37);
            this.textBox5.TabIndex = 136;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(879, 849);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(242, 37);
            this.textBox4.TabIndex = 135;
            // 
            // Observatii6
            // 
            this.Observatii6.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Observatii6.Location = new System.Drawing.Point(1118, 654);
            this.Observatii6.Multiline = true;
            this.Observatii6.Name = "Observatii6";
            this.Observatii6.Size = new System.Drawing.Size(613, 34);
            this.Observatii6.TabIndex = 134;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(973, 652);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(137, 33);
            this.label10.TabIndex = 133;
            this.label10.Text = "Observatii:";
            // 
            // Rinichi_stang_ip
            // 
            this.Rinichi_stang_ip.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rinichi_stang_ip.Location = new System.Drawing.Point(1596, 474);
            this.Rinichi_stang_ip.Name = "Rinichi_stang_ip";
            this.Rinichi_stang_ip.Size = new System.Drawing.Size(87, 39);
            this.Rinichi_stang_ip.TabIndex = 132;
            // 
            // Rinichi_stang_diametru
            // 
            this.Rinichi_stang_diametru.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rinichi_stang_diametru.Location = new System.Drawing.Point(1410, 477);
            this.Rinichi_stang_diametru.Name = "Rinichi_stang_diametru";
            this.Rinichi_stang_diametru.Size = new System.Drawing.Size(87, 39);
            this.Rinichi_stang_diametru.TabIndex = 131;
            // 
            // Splina_ecostructura
            // 
            this.Splina_ecostructura.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Splina_ecostructura.FormattingEnabled = true;
            this.Splina_ecostructura.Items.AddRange(new object[] {
            "Omogena",
            "Neomogena"});
            this.Splina_ecostructura.Location = new System.Drawing.Point(1407, 318);
            this.Splina_ecostructura.Name = "Splina_ecostructura";
            this.Splina_ecostructura.Size = new System.Drawing.Size(324, 34);
            this.Splina_ecostructura.TabIndex = 130;
            // 
            // Concluzii
            // 
            this.Concluzii.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Concluzii.Location = new System.Drawing.Point(976, 694);
            this.Concluzii.Multiline = true;
            this.Concluzii.Name = "Concluzii";
            this.Concluzii.Size = new System.Drawing.Size(755, 136);
            this.Concluzii.TabIndex = 129;
            // 
            // Vezica_urinara_dimensiuni
            // 
            this.Vezica_urinara_dimensiuni.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vezica_urinara_dimensiuni.Location = new System.Drawing.Point(1297, 606);
            this.Vezica_urinara_dimensiuni.Name = "Vezica_urinara_dimensiuni";
            this.Vezica_urinara_dimensiuni.Size = new System.Drawing.Size(136, 39);
            this.Vezica_urinara_dimensiuni.TabIndex = 128;
            // 
            // UtersauProstata
            // 
            this.UtersauProstata.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UtersauProstata.Location = new System.Drawing.Point(1265, 557);
            this.UtersauProstata.Name = "UtersauProstata";
            this.UtersauProstata.Size = new System.Drawing.Size(277, 39);
            this.UtersauProstata.TabIndex = 127;
            // 
            // Observatii5
            // 
            this.Observatii5.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Observatii5.Location = new System.Drawing.Point(1119, 519);
            this.Observatii5.Multiline = true;
            this.Observatii5.Name = "Observatii5";
            this.Observatii5.Size = new System.Drawing.Size(612, 34);
            this.Observatii5.TabIndex = 126;
            // 
            // Observatii4
            // 
            this.Observatii4.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Observatii4.Location = new System.Drawing.Point(1113, 440);
            this.Observatii4.Multiline = true;
            this.Observatii4.Name = "Observatii4";
            this.Observatii4.Size = new System.Drawing.Size(613, 34);
            this.Observatii4.TabIndex = 125;
            // 
            // Rinichi_drept_ip
            // 
            this.Rinichi_drept_ip.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rinichi_drept_ip.Location = new System.Drawing.Point(1596, 403);
            this.Rinichi_drept_ip.Name = "Rinichi_drept_ip";
            this.Rinichi_drept_ip.Size = new System.Drawing.Size(87, 34);
            this.Rinichi_drept_ip.TabIndex = 124;
            // 
            // Rinichi_drep_diametru
            // 
            this.Rinichi_drep_diametru.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rinichi_drep_diametru.Location = new System.Drawing.Point(1410, 398);
            this.Rinichi_drep_diametru.Name = "Rinichi_drep_diametru";
            this.Rinichi_drep_diametru.Size = new System.Drawing.Size(82, 39);
            this.Rinichi_drep_diametru.TabIndex = 123;
            // 
            // Splina_dimensiuni
            // 
            this.Splina_dimensiuni.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Splina_dimensiuni.Location = new System.Drawing.Point(1217, 318);
            this.Splina_dimensiuni.Name = "Splina_dimensiuni";
            this.Splina_dimensiuni.Size = new System.Drawing.Size(105, 34);
            this.Splina_dimensiuni.TabIndex = 122;
            // 
            // Observatii3
            // 
            this.Observatii3.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Observatii3.Location = new System.Drawing.Point(1118, 358);
            this.Observatii3.Multiline = true;
            this.Observatii3.Name = "Observatii3";
            this.Observatii3.Size = new System.Drawing.Size(613, 34);
            this.Observatii3.TabIndex = 121;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(1689, 477);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(55, 33);
            this.label43.TabIndex = 120;
            this.label43.Text = "mm";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(1503, 477);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(92, 33);
            this.label44.TabIndex = 119;
            this.label44.Text = "mm Ip:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(958, 480);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(419, 33);
            this.label42.TabIndex = 118;
            this.label42.Text = "Rinichi stang:Dimensiuni:Diametru:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(1332, 315);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(69, 34);
            this.label38.TabIndex = 117;
            this.label38.Text = "mm ";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(1462, 608);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(55, 33);
            this.label37.TabIndex = 116;
            this.label37.Text = "mm";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(1689, 407);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(55, 33);
            this.label36.TabIndex = 115;
            this.label36.Text = "mm";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(1064, 560);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(169, 33);
            this.label35.TabIndex = 114;
            this.label35.Text = "Uter/Prostata:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(1498, 404);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(92, 33);
            this.label34.TabIndex = 113;
            this.label34.Text = "mm Ip:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(846, 685);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(132, 33);
            this.label32.TabIndex = 112;
            this.label32.Text = "Concluzii:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(943, 604);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(323, 33);
            this.label31.TabIndex = 111;
            this.label31.Text = "Vezica Urinara:Dimensiuni:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(970, 522);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(137, 33);
            this.label25.TabIndex = 110;
            this.label25.Text = "Observatii:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(970, 444);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(137, 33);
            this.label23.TabIndex = 109;
            this.label23.Text = "Observatii:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(983, 404);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(418, 33);
            this.label22.TabIndex = 108;
            this.label22.Text = "Rinichi drept:Dimensiuni:Diametru:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(970, 356);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(137, 33);
            this.label20.TabIndex = 107;
            this.label20.Text = "Observatii:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(970, 316);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(232, 33);
            this.label19.TabIndex = 106;
            this.label19.Text = "Splina:Dimensiuni:";
            // 
            // Genereaza_pdf
            // 
            this.Genereaza_pdf.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genereaza_pdf.Location = new System.Drawing.Point(780, 939);
            this.Genereaza_pdf.Name = "Genereaza_pdf";
            this.Genereaza_pdf.Size = new System.Drawing.Size(445, 59);
            this.Genereaza_pdf.TabIndex = 137;
            this.Genereaza_pdf.Text = "Genereaza pdf";
            this.Genereaza_pdf.UseVisualStyleBackColor = true;
            this.Genereaza_pdf.Click += new System.EventHandler(this.Genereaza_pdf_Click);
            // 
            // VP
            // 
            this.VP.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VP.Location = new System.Drawing.Point(116, 595);
            this.VP.Name = "VP";
            this.VP.Size = new System.Drawing.Size(432, 34);
            this.VP.TabIndex = 138;
            // 
            // CBP
            // 
            this.CBP.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBP.Location = new System.Drawing.Point(129, 637);
            this.CBP.Multiline = true;
            this.CBP.Name = "CBP";
            this.CBP.Size = new System.Drawing.Size(419, 33);
            this.CBP.TabIndex = 139;
            // 
            // Dapld
            // 
            this.Dapld.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dapld.Location = new System.Drawing.Point(160, 504);
            this.Dapld.Multiline = true;
            this.Dapld.Name = "Dapld";
            this.Dapld.Size = new System.Drawing.Size(388, 35);
            this.Dapld.TabIndex = 140;
            // 
            // Ecografie_abdominala
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1775, 1033);
            this.Controls.Add(this.Dapld);
            this.Controls.Add(this.CBP);
            this.Controls.Add(this.VP);
            this.Controls.Add(this.Genereaza_pdf);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.Observatii6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Rinichi_stang_ip);
            this.Controls.Add(this.Rinichi_stang_diametru);
            this.Controls.Add(this.Splina_ecostructura);
            this.Controls.Add(this.Concluzii);
            this.Controls.Add(this.Vezica_urinara_dimensiuni);
            this.Controls.Add(this.UtersauProstata);
            this.Controls.Add(this.Observatii5);
            this.Controls.Add(this.Observatii4);
            this.Controls.Add(this.Rinichi_drept_ip);
            this.Controls.Add(this.Rinichi_drep_diametru);
            this.Controls.Add(this.Splina_dimensiuni);
            this.Controls.Add(this.Observatii3);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Vena_splenica_dimensiuni);
            this.Controls.Add(this.Observatii2);
            this.Controls.Add(this.Pereti_antrali);
            this.Controls.Add(this.Observatii1);
            this.Controls.Add(this.Dimensiuni1);
            this.Controls.Add(this.Dadls);
            this.Controls.Add(this.Colecist);
            this.Controls.Add(this.Pancreas_cu_ecostructura);
            this.Controls.Add(this.Ficat_cu_ecostructura);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Pacient);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Nr);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Ecografie_abdominala";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ecografie Abdominala";
            this.Load += new System.EventHandler(this.Ecografie_abdominala_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox Pacient;
        private System.Windows.Forms.TextBox Data;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Nr;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Vena_splenica_dimensiuni;
        private System.Windows.Forms.TextBox Observatii2;
        private System.Windows.Forms.TextBox Pereti_antrali;
        private System.Windows.Forms.TextBox Observatii1;
        private System.Windows.Forms.TextBox Dimensiuni1;
        private System.Windows.Forms.TextBox Dadls;
        private System.Windows.Forms.TextBox Colecist;
        private System.Windows.Forms.TextBox Pancreas_cu_ecostructura;
        private System.Windows.Forms.TextBox Ficat_cu_ecostructura;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox Observatii6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Rinichi_stang_ip;
        private System.Windows.Forms.TextBox Rinichi_stang_diametru;
        private System.Windows.Forms.ComboBox Splina_ecostructura;
        private System.Windows.Forms.TextBox Concluzii;
        private System.Windows.Forms.TextBox Vezica_urinara_dimensiuni;
        private System.Windows.Forms.TextBox UtersauProstata;
        private System.Windows.Forms.TextBox Observatii5;
        private System.Windows.Forms.TextBox Observatii4;
        private System.Windows.Forms.TextBox Rinichi_drept_ip;
        private System.Windows.Forms.TextBox Rinichi_drep_diametru;
        private System.Windows.Forms.TextBox Splina_dimensiuni;
        private System.Windows.Forms.TextBox Observatii3;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button Genereaza_pdf;
        private System.Windows.Forms.TextBox VP;
        private System.Windows.Forms.TextBox CBP;
        private System.Windows.Forms.TextBox Dapld;
    }
}