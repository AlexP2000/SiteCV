﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buton7 = new System.Windows.Forms.Button();
            this.buton8 = new System.Windows.Forms.Button();
            this.buton9 = new System.Windows.Forms.Button();
            this.button_impartire = new System.Windows.Forms.Button();
            this.buton_ridicare_la_putere = new System.Windows.Forms.Button();
            this.buton_la_suta = new System.Windows.Forms.Button();
            this.buton_inmultire = new System.Windows.Forms.Button();
            this.buton6 = new System.Windows.Forms.Button();
            this.buton5 = new System.Windows.Forms.Button();
            this.buton4 = new System.Windows.Forms.Button();
            this.buton_scadere = new System.Windows.Forms.Button();
            this.buton3 = new System.Windows.Forms.Button();
            this.buton2 = new System.Windows.Forms.Button();
            this.buton1 = new System.Windows.Forms.Button();
            this.buton_egal = new System.Windows.Forms.Button();
            this.buton_plus = new System.Windows.Forms.Button();
            this.buton_virgula = new System.Windows.Forms.Button();
            this.buton0 = new System.Windows.Forms.Button();
            this.buton_reset = new System.Windows.Forms.Button();
            this.buton_iesire = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(698, -1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 76);
            this.button1.TabIndex = 0;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(144, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Calculator";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(130, 130);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // buton7
            // 
            this.buton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton7.Location = new System.Drawing.Point(26, 275);
            this.buton7.Name = "buton7";
            this.buton7.Size = new System.Drawing.Size(119, 73);
            this.buton7.TabIndex = 3;
            this.buton7.Text = "7";
            this.buton7.UseVisualStyleBackColor = true;
            this.buton7.Click += new System.EventHandler(this.buton_Click);
            // 
            // buton8
            // 
            this.buton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton8.Location = new System.Drawing.Point(165, 275);
            this.buton8.Name = "buton8";
            this.buton8.Size = new System.Drawing.Size(116, 73);
            this.buton8.TabIndex = 4;
            this.buton8.Text = "8";
            this.buton8.UseVisualStyleBackColor = true;
            this.buton8.Click += new System.EventHandler(this.buton_Click);
            // 
            // buton9
            // 
            this.buton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton9.Location = new System.Drawing.Point(325, 275);
            this.buton9.Name = "buton9";
            this.buton9.Size = new System.Drawing.Size(119, 73);
            this.buton9.TabIndex = 5;
            this.buton9.Text = "9";
            this.buton9.UseVisualStyleBackColor = true;
            this.buton9.Click += new System.EventHandler(this.buton_Click);
            // 
            // button_impartire
            // 
            this.button_impartire.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_impartire.Location = new System.Drawing.Point(490, 275);
            this.button_impartire.Name = "button_impartire";
            this.button_impartire.Size = new System.Drawing.Size(116, 73);
            this.button_impartire.TabIndex = 6;
            this.button_impartire.Text = "/";
            this.button_impartire.UseVisualStyleBackColor = true;
            this.button_impartire.Click += new System.EventHandler(this.operator_click);
            // 
            // buton_ridicare_la_putere
            // 
            this.buton_ridicare_la_putere.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton_ridicare_la_putere.Location = new System.Drawing.Point(641, 275);
            this.buton_ridicare_la_putere.Name = "buton_ridicare_la_putere";
            this.buton_ridicare_la_putere.Size = new System.Drawing.Size(125, 73);
            this.buton_ridicare_la_putere.TabIndex = 7;
            this.buton_ridicare_la_putere.Text = "reset";
            this.buton_ridicare_la_putere.UseVisualStyleBackColor = true;
            this.buton_ridicare_la_putere.Click += new System.EventHandler(this.buton_ridicare_la_putere_Click);
            // 
            // buton_la_suta
            // 
            this.buton_la_suta.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton_la_suta.Location = new System.Drawing.Point(645, 371);
            this.buton_la_suta.Name = "buton_la_suta";
            this.buton_la_suta.Size = new System.Drawing.Size(125, 73);
            this.buton_la_suta.TabIndex = 12;
            this.buton_la_suta.Text = "%";
            this.buton_la_suta.UseVisualStyleBackColor = true;
            // 
            // buton_inmultire
            // 
            this.buton_inmultire.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton_inmultire.Location = new System.Drawing.Point(494, 371);
            this.buton_inmultire.Name = "buton_inmultire";
            this.buton_inmultire.Size = new System.Drawing.Size(116, 73);
            this.buton_inmultire.TabIndex = 11;
            this.buton_inmultire.Text = "*";
            this.buton_inmultire.UseVisualStyleBackColor = true;
            this.buton_inmultire.Click += new System.EventHandler(this.operator_click);
            // 
            // buton6
            // 
            this.buton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton6.Location = new System.Drawing.Point(329, 371);
            this.buton6.Name = "buton6";
            this.buton6.Size = new System.Drawing.Size(119, 73);
            this.buton6.TabIndex = 10;
            this.buton6.Text = "6";
            this.buton6.UseVisualStyleBackColor = true;
            this.buton6.Click += new System.EventHandler(this.buton_Click);
            // 
            // buton5
            // 
            this.buton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton5.Location = new System.Drawing.Point(169, 371);
            this.buton5.Name = "buton5";
            this.buton5.Size = new System.Drawing.Size(116, 73);
            this.buton5.TabIndex = 9;
            this.buton5.Text = "5";
            this.buton5.UseVisualStyleBackColor = true;
            this.buton5.Click += new System.EventHandler(this.buton_Click);
            // 
            // buton4
            // 
            this.buton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton4.Location = new System.Drawing.Point(30, 371);
            this.buton4.Name = "buton4";
            this.buton4.Size = new System.Drawing.Size(119, 73);
            this.buton4.TabIndex = 8;
            this.buton4.Text = "4";
            this.buton4.UseVisualStyleBackColor = true;
            this.buton4.Click += new System.EventHandler(this.buton_Click);
            // 
            // buton_scadere
            // 
            this.buton_scadere.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton_scadere.Location = new System.Drawing.Point(494, 489);
            this.buton_scadere.Name = "buton_scadere";
            this.buton_scadere.Size = new System.Drawing.Size(116, 73);
            this.buton_scadere.TabIndex = 16;
            this.buton_scadere.Text = "-";
            this.buton_scadere.UseVisualStyleBackColor = true;
            this.buton_scadere.Click += new System.EventHandler(this.operator_click);
            // 
            // buton3
            // 
            this.buton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton3.Location = new System.Drawing.Point(329, 489);
            this.buton3.Name = "buton3";
            this.buton3.Size = new System.Drawing.Size(119, 73);
            this.buton3.TabIndex = 15;
            this.buton3.Text = "3";
            this.buton3.UseVisualStyleBackColor = true;
            this.buton3.Click += new System.EventHandler(this.buton_Click);
            // 
            // buton2
            // 
            this.buton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton2.Location = new System.Drawing.Point(169, 489);
            this.buton2.Name = "buton2";
            this.buton2.Size = new System.Drawing.Size(116, 73);
            this.buton2.TabIndex = 14;
            this.buton2.Text = "2";
            this.buton2.UseVisualStyleBackColor = true;
            this.buton2.Click += new System.EventHandler(this.buton_Click);
            // 
            // buton1
            // 
            this.buton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton1.Location = new System.Drawing.Point(30, 489);
            this.buton1.Name = "buton1";
            this.buton1.Size = new System.Drawing.Size(119, 73);
            this.buton1.TabIndex = 13;
            this.buton1.Text = "1";
            this.buton1.UseVisualStyleBackColor = true;
            this.buton1.Click += new System.EventHandler(this.buton_Click);
            // 
            // buton_egal
            // 
            this.buton_egal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton_egal.Location = new System.Drawing.Point(641, 489);
            this.buton_egal.Name = "buton_egal";
            this.buton_egal.Size = new System.Drawing.Size(125, 179);
            this.buton_egal.TabIndex = 22;
            this.buton_egal.Text = "=";
            this.buton_egal.UseVisualStyleBackColor = true;
            this.buton_egal.Click += new System.EventHandler(this.buton_egal_Click);
            // 
            // buton_plus
            // 
            this.buton_plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton_plus.Location = new System.Drawing.Point(490, 595);
            this.buton_plus.Name = "buton_plus";
            this.buton_plus.Size = new System.Drawing.Size(116, 73);
            this.buton_plus.TabIndex = 21;
            this.buton_plus.Text = "+";
            this.buton_plus.UseVisualStyleBackColor = true;
            this.buton_plus.Click += new System.EventHandler(this.operator_click);
            // 
            // buton_virgula
            // 
            this.buton_virgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton_virgula.Location = new System.Drawing.Point(325, 595);
            this.buton_virgula.Name = "buton_virgula";
            this.buton_virgula.Size = new System.Drawing.Size(119, 73);
            this.buton_virgula.TabIndex = 20;
            this.buton_virgula.Text = ",";
            this.buton_virgula.UseVisualStyleBackColor = true;
            this.buton_virgula.Click += new System.EventHandler(this.buton_Click);
            // 
            // buton0
            // 
            this.buton0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton0.Location = new System.Drawing.Point(26, 595);
            this.buton0.Name = "buton0";
            this.buton0.Size = new System.Drawing.Size(255, 73);
            this.buton0.TabIndex = 18;
            this.buton0.Text = "0";
            this.buton0.UseVisualStyleBackColor = true;
            this.buton0.Click += new System.EventHandler(this.buton_Click);
            // 
            // buton_reset
            // 
            this.buton_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton_reset.Location = new System.Drawing.Point(54, 717);
            this.buton_reset.Name = "buton_reset";
            this.buton_reset.Size = new System.Drawing.Size(255, 73);
            this.buton_reset.TabIndex = 23;
            this.buton_reset.Text = "Reset";
            this.buton_reset.UseVisualStyleBackColor = true;
            this.buton_reset.Click += new System.EventHandler(this.buton_reset_Click);
            // 
            // buton_iesire
            // 
            this.buton_iesire.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buton_iesire.Location = new System.Drawing.Point(411, 717);
            this.buton_iesire.Name = "buton_iesire";
            this.buton_iesire.Size = new System.Drawing.Size(255, 73);
            this.buton_iesire.TabIndex = 24;
            this.buton_iesire.Text = "Iesire";
            this.buton_iesire.UseVisualStyleBackColor = true;
            this.buton_iesire.Click += new System.EventHandler(this.buton_iesire_Click);
            // 
            // result
            // 
            this.result.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.result.Location = new System.Drawing.Point(26, 135);
            this.result.Multiline = true;
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(740, 109);
            this.result.TabIndex = 25;
            this.result.Text = "0";
            this.result.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 815);
            this.Controls.Add(this.result);
            this.Controls.Add(this.buton_iesire);
            this.Controls.Add(this.buton_reset);
            this.Controls.Add(this.buton_egal);
            this.Controls.Add(this.buton_plus);
            this.Controls.Add(this.buton_virgula);
            this.Controls.Add(this.buton0);
            this.Controls.Add(this.buton_scadere);
            this.Controls.Add(this.buton3);
            this.Controls.Add(this.buton2);
            this.Controls.Add(this.buton1);
            this.Controls.Add(this.buton_la_suta);
            this.Controls.Add(this.buton_inmultire);
            this.Controls.Add(this.buton6);
            this.Controls.Add(this.buton5);
            this.Controls.Add(this.buton4);
            this.Controls.Add(this.buton_ridicare_la_putere);
            this.Controls.Add(this.button_impartire);
            this.Controls.Add(this.buton9);
            this.Controls.Add(this.buton8);
            this.Controls.Add(this.buton7);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buton7;
        private System.Windows.Forms.Button buton8;
        private System.Windows.Forms.Button buton9;
        private System.Windows.Forms.Button button_impartire;
        private System.Windows.Forms.Button buton_ridicare_la_putere;
        private System.Windows.Forms.Button buton_la_suta;
        private System.Windows.Forms.Button buton_inmultire;
        private System.Windows.Forms.Button buton6;
        private System.Windows.Forms.Button buton5;
        private System.Windows.Forms.Button buton4;
        private System.Windows.Forms.Button buton_scadere;
        private System.Windows.Forms.Button buton3;
        private System.Windows.Forms.Button buton2;
        private System.Windows.Forms.Button buton1;
        private System.Windows.Forms.Button buton_egal;
        private System.Windows.Forms.Button buton_plus;
        private System.Windows.Forms.Button buton_virgula;
        private System.Windows.Forms.Button buton0;
        private System.Windows.Forms.Button buton_reset;
        private System.Windows.Forms.Button buton_iesire;
        private System.Windows.Forms.TextBox result;
    }
}

