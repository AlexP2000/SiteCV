﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototip_jurist
{
    public class Person
    {
        public string Nume, Prenume, localitate, serie;
        public int Numar, CNP;
    }
}
