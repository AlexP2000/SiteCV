﻿namespace Prototip_jurist
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Foaie = new System.Windows.Forms.ComboBox();
            this.Genereaza_contract = new System.Windows.Forms.Button();
            this.NumeSocietate = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Forma_de_activitate = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Oras = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Strada = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.NumarStrada = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.afisare_tabel = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.Alege = new System.Windows.Forms.Button();
            this.Cale = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.judet = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Bloc = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Scara = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.etaj = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Ap = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.NORC = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.Cont = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.Deschis = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.CUI = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.telefon = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.sucursala = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.functia = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.reprezentat = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.Nr = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.Data = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label26 = new System.Windows.Forms.Label();
            this.NumeSocietate1 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.judet1 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.oras1 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.strada1 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.Numar1 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.Codpostal1 = new System.Windows.Forms.TextBox();
            this.Coddeindentificarefiscala1 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.telefon1 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.fax1 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.functia1 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.reprezentant1 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.sucursala1 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.cont1 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.deschis1 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.Vigoare = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.afisare_tabel)).BeginInit();
            this.SuspendLayout();
            // 
            // Foaie
            // 
            this.Foaie.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Foaie.FormattingEnabled = true;
            this.Foaie.Location = new System.Drawing.Point(108, 203);
            this.Foaie.Name = "Foaie";
            this.Foaie.Size = new System.Drawing.Size(226, 39);
            this.Foaie.TabIndex = 39;
            this.Foaie.SelectedIndexChanged += new System.EventHandler(this.Foaie_SelectedIndexChanged);
            // 
            // Genereaza_contract
            // 
            this.Genereaza_contract.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Genereaza_contract.Location = new System.Drawing.Point(817, 919);
            this.Genereaza_contract.Name = "Genereaza_contract";
            this.Genereaza_contract.Size = new System.Drawing.Size(340, 46);
            this.Genereaza_contract.TabIndex = 36;
            this.Genereaza_contract.Text = "Genereaza Contract";
            this.Genereaza_contract.UseVisualStyleBackColor = true;
            this.Genereaza_contract.Click += new System.EventHandler(this.Genereaza_contract_Click);
            // 
            // NumeSocietate
            // 
            this.NumeSocietate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NumeSocietate.Location = new System.Drawing.Point(243, 507);
            this.NumeSocietate.Name = "NumeSocietate";
            this.NumeSocietate.Size = new System.Drawing.Size(277, 38);
            this.NumeSocietate.TabIndex = 35;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(8, 510);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(224, 32);
            this.label7.TabIndex = 34;
            this.label7.Text = "Nume Societate:";
            // 
            // Forma_de_activitate
            // 
            this.Forma_de_activitate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Forma_de_activitate.Location = new System.Drawing.Point(276, 551);
            this.Forma_de_activitate.Name = "Forma_de_activitate";
            this.Forma_de_activitate.Size = new System.Drawing.Size(244, 38);
            this.Forma_de_activitate.TabIndex = 33;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(7, 557);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(263, 32);
            this.label6.TabIndex = 32;
            this.label6.Text = "Forma de activitate:";
            // 
            // Oras
            // 
            this.Oras.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Oras.Location = new System.Drawing.Point(640, 507);
            this.Oras.Name = "Oras";
            this.Oras.Size = new System.Drawing.Size(201, 38);
            this.Oras.TabIndex = 31;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(536, 507);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 38);
            this.label5.TabIndex = 30;
            this.label5.Text = "Oras:";
            // 
            // Strada
            // 
            this.Strada.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Strada.Location = new System.Drawing.Point(110, 599);
            this.Strada.Name = "Strada";
            this.Strada.Size = new System.Drawing.Size(405, 38);
            this.Strada.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(2, 606);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 32);
            this.label4.TabIndex = 28;
            this.label4.Text = "Strada:";
            // 
            // NumarStrada
            // 
            this.NumarStrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NumarStrada.Location = new System.Drawing.Point(674, 600);
            this.NumarStrada.Name = "NumarStrada";
            this.NumarStrada.Size = new System.Drawing.Size(167, 38);
            this.NumarStrada.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(536, 606);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 38);
            this.label3.TabIndex = 26;
            this.label3.Text = "Numar:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.afisare_tabel);
            this.panel1.Location = new System.Drawing.Point(2, 250);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(839, 248);
            this.panel1.TabIndex = 25;
            // 
            // afisare_tabel
            // 
            this.afisare_tabel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.afisare_tabel.Location = new System.Drawing.Point(0, 0);
            this.afisare_tabel.Name = "afisare_tabel";
            this.afisare_tabel.RowHeadersWidth = 51;
            this.afisare_tabel.RowTemplate.Height = 24;
            this.afisare_tabel.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.afisare_tabel.Size = new System.Drawing.Size(839, 251);
            this.afisare_tabel.TabIndex = 0;
            this.afisare_tabel.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.afisare_tabel_CellClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(8, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 32);
            this.label2.TabIndex = 24;
            this.label2.Text = "Foaie:";
            // 
            // Alege
            // 
            this.Alege.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Alege.Location = new System.Drawing.Point(555, 119);
            this.Alege.Name = "Alege";
            this.Alege.Size = new System.Drawing.Size(189, 46);
            this.Alege.TabIndex = 23;
            this.Alege.Text = "Alege";
            this.Alege.UseVisualStyleBackColor = true;
            this.Alege.Click += new System.EventHandler(this.Alege_Click);
            // 
            // Cale
            // 
            this.Cale.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Cale.Location = new System.Drawing.Point(112, 127);
            this.Cale.Name = "Cale";
            this.Cale.Size = new System.Drawing.Size(437, 38);
            this.Cale.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(23, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 32);
            this.label1.TabIndex = 21;
            this.label1.Text = "Cale:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(23, 168);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(690, 32);
            this.label9.TabIndex = 40;
            this.label9.Text = "Alegeti o foaie de unde calculatorul sa va preia datele";
            // 
            // judet
            // 
            this.judet.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.judet.Location = new System.Drawing.Point(665, 552);
            this.judet.Name = "judet";
            this.judet.Size = new System.Drawing.Size(176, 38);
            this.judet.TabIndex = 42;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(536, 552);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 38);
            this.label10.TabIndex = 41;
            this.label10.Text = "Judet:";
            // 
            // Bloc
            // 
            this.Bloc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Bloc.Location = new System.Drawing.Point(99, 650);
            this.Bloc.Name = "Bloc";
            this.Bloc.Size = new System.Drawing.Size(117, 38);
            this.Bloc.TabIndex = 46;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(13, 652);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 32);
            this.label11.TabIndex = 45;
            this.label11.Text = "Bloc:";
            // 
            // Scara
            // 
            this.Scara.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Scara.Location = new System.Drawing.Point(354, 652);
            this.Scara.Name = "Scara";
            this.Scara.Size = new System.Drawing.Size(117, 38);
            this.Scara.TabIndex = 44;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.Location = new System.Drawing.Point(240, 652);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 32);
            this.label12.TabIndex = 43;
            this.label12.Text = "Scara:";
            // 
            // etaj
            // 
            this.etaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.etaj.Location = new System.Drawing.Point(555, 652);
            this.etaj.Name = "etaj";
            this.etaj.Size = new System.Drawing.Size(117, 38);
            this.etaj.TabIndex = 50;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.Location = new System.Drawing.Point(484, 652);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 32);
            this.label13.TabIndex = 49;
            this.label13.Text = "Etaj:";
            // 
            // Ap
            // 
            this.Ap.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Ap.Location = new System.Drawing.Point(741, 653);
            this.Ap.Name = "Ap";
            this.Ap.Size = new System.Drawing.Size(100, 38);
            this.Ap.TabIndex = 48;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.Location = new System.Drawing.Point(687, 653);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 32);
            this.label14.TabIndex = 47;
            this.label14.Text = "Ap:";
            // 
            // NORC
            // 
            this.NORC.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NORC.Location = new System.Drawing.Point(112, 697);
            this.NORC.Name = "NORC";
            this.NORC.Size = new System.Drawing.Size(370, 38);
            this.NORC.TabIndex = 52;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.Location = new System.Drawing.Point(13, 703);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 32);
            this.label15.TabIndex = 51;
            this.label15.Text = "NORC:";
            // 
            // Cont
            // 
            this.Cont.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Cont.Location = new System.Drawing.Point(598, 750);
            this.Cont.Name = "Cont";
            this.Cont.Size = new System.Drawing.Size(243, 38);
            this.Cont.TabIndex = 60;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.Location = new System.Drawing.Point(497, 748);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(82, 32);
            this.label16.TabIndex = 59;
            this.label16.Text = "Cont:";
            // 
            // Deschis
            // 
            this.Deschis.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Deschis.Location = new System.Drawing.Point(153, 794);
            this.Deschis.Name = "Deschis";
            this.Deschis.Size = new System.Drawing.Size(232, 38);
            this.Deschis.TabIndex = 58;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.Location = new System.Drawing.Point(2, 797);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(123, 32);
            this.label17.TabIndex = 57;
            this.label17.Text = "Deschis:";
            // 
            // CUI
            // 
            this.CUI.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.CUI.Location = new System.Drawing.Point(555, 697);
            this.CUI.Name = "CUI";
            this.CUI.Size = new System.Drawing.Size(286, 38);
            this.CUI.TabIndex = 56;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.Location = new System.Drawing.Point(488, 700);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 32);
            this.label18.TabIndex = 55;
            this.label18.Text = "CUI:";
            // 
            // telefon
            // 
            this.telefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.telefon.Location = new System.Drawing.Point(181, 750);
            this.telefon.Name = "telefon";
            this.telefon.Size = new System.Drawing.Size(301, 38);
            this.telefon.TabIndex = 54;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.Location = new System.Drawing.Point(11, 750);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(164, 32);
            this.label19.TabIndex = 53;
            this.label19.Text = "Telefon/fax:";
            // 
            // sucursala
            // 
            this.sucursala.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.sucursala.Location = new System.Drawing.Point(555, 797);
            this.sucursala.Name = "sucursala";
            this.sucursala.Size = new System.Drawing.Size(286, 38);
            this.sucursala.TabIndex = 62;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label20.Location = new System.Drawing.Point(400, 800);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(149, 32);
            this.label20.TabIndex = 61;
            this.label20.Text = "Sucursala:";
            // 
            // functia
            // 
            this.functia.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.functia.Location = new System.Drawing.Point(674, 852);
            this.functia.Name = "functia";
            this.functia.Size = new System.Drawing.Size(167, 38);
            this.functia.TabIndex = 66;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label21.Location = new System.Drawing.Point(539, 857);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(116, 32);
            this.label21.TabIndex = 65;
            this.label21.Text = "Functia:";
            // 
            // reprezentat
            // 
            this.reprezentat.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.reprezentat.Location = new System.Drawing.Point(201, 851);
            this.reprezentat.Name = "reprezentat";
            this.reprezentat.Size = new System.Drawing.Size(331, 38);
            this.reprezentat.TabIndex = 64;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label22.Location = new System.Drawing.Point(2, 852);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(193, 32);
            this.label22.TabIndex = 63;
            this.label22.Text = "Reprezentant:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label23.Location = new System.Drawing.Point(941, 4);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(135, 36);
            this.label23.TabIndex = 67;
            this.label23.Text = "Contarct";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label24.Location = new System.Drawing.Point(842, 44);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 29);
            this.label24.TabIndex = 68;
            this.label24.Text = "Nr:";
            // 
            // Nr
            // 
            this.Nr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Nr.Location = new System.Drawing.Point(896, 44);
            this.Nr.Name = "Nr";
            this.Nr.Size = new System.Drawing.Size(134, 30);
            this.Nr.TabIndex = 69;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label25.Location = new System.Drawing.Point(1041, 44);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(59, 29);
            this.label25.TabIndex = 70;
            this.label25.Text = "Din:";
            // 
            // Data
            // 
            this.Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Data.Location = new System.Drawing.Point(1106, 43);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(224, 30);
            this.Data.TabIndex = 71;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(58, 84);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(555, 32);
            this.label8.TabIndex = 72;
            this.label8.Text = "Selectati firmele cu care realizati contractul";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label26.Location = new System.Drawing.Point(1153, 168);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(486, 32);
            this.label26.TabIndex = 74;
            this.label26.Text = "Scrieti firma care realizeaza contactul";
            // 
            // NumeSocietate1
            // 
            this.NumeSocietate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NumeSocietate1.Location = new System.Drawing.Point(1130, 247);
            this.NumeSocietate1.Name = "NumeSocietate1";
            this.NumeSocietate1.Size = new System.Drawing.Size(752, 38);
            this.NumeSocietate1.TabIndex = 76;
            this.NumeSocietate1.Text = "SERVICIUL LOCAL ,,ECO VALEA MUNTELUI COMANESTI\"";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label27.Location = new System.Drawing.Point(885, 253);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(239, 32);
            this.label27.TabIndex = 75;
            this.label27.Text = "Nume Societate:";
            // 
            // judet1
            // 
            this.judet1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.judet1.Location = new System.Drawing.Point(998, 291);
            this.judet1.Name = "judet1";
            this.judet1.Size = new System.Drawing.Size(181, 38);
            this.judet1.TabIndex = 80;
            this.judet1.Text = "Bacau";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label29.Location = new System.Drawing.Point(886, 291);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(106, 38);
            this.label29.TabIndex = 79;
            this.label29.Text = "Judet:";
            // 
            // oras1
            // 
            this.oras1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oras1.Location = new System.Drawing.Point(1363, 291);
            this.oras1.Name = "oras1";
            this.oras1.Size = new System.Drawing.Size(201, 38);
            this.oras1.TabIndex = 78;
            this.oras1.Text = "Comanesti";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label30.Location = new System.Drawing.Point(1244, 292);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(98, 38);
            this.label30.TabIndex = 77;
            this.label30.Text = "Oras:";
            // 
            // strada1
            // 
            this.strada1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.strada1.Location = new System.Drawing.Point(1067, 388);
            this.strada1.Name = "strada1";
            this.strada1.Size = new System.Drawing.Size(405, 38);
            this.strada1.TabIndex = 84;
            this.strada1.Text = "Moldovei";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label28.Location = new System.Drawing.Point(959, 395);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(113, 32);
            this.label28.TabIndex = 83;
            this.label28.Text = "Strada:";
            // 
            // Numar1
            // 
            this.Numar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Numar1.Location = new System.Drawing.Point(1608, 389);
            this.Numar1.Name = "Numar1";
            this.Numar1.Size = new System.Drawing.Size(167, 38);
            this.Numar1.TabIndex = 82;
            this.Numar1.Text = "118";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label31.Location = new System.Drawing.Point(1478, 386);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(124, 38);
            this.label31.TabIndex = 81;
            this.label31.Text = "Numar:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label32.Location = new System.Drawing.Point(959, 453);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(186, 38);
            this.label32.TabIndex = 85;
            this.label32.Text = "Cod Postal:";
            // 
            // Codpostal1
            // 
            this.Codpostal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Codpostal1.Location = new System.Drawing.Point(1142, 455);
            this.Codpostal1.Name = "Codpostal1";
            this.Codpostal1.Size = new System.Drawing.Size(273, 38);
            this.Codpostal1.TabIndex = 86;
            this.Codpostal1.Text = "605200";
            // 
            // Coddeindentificarefiscala1
            // 
            this.Coddeindentificarefiscala1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Coddeindentificarefiscala1.Location = new System.Drawing.Point(1376, 510);
            this.Coddeindentificarefiscala1.Name = "Coddeindentificarefiscala1";
            this.Coddeindentificarefiscala1.Size = new System.Drawing.Size(432, 38);
            this.Coddeindentificarefiscala1.TabIndex = 88;
            this.Coddeindentificarefiscala1.Text = "RO40101462";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label33.Location = new System.Drawing.Point(959, 509);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(417, 38);
            this.label33.TabIndex = 87;
            this.label33.Text = "Cod de indentificare fiscala:";
            // 
            // telefon1
            // 
            this.telefon1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.telefon1.Location = new System.Drawing.Point(1091, 570);
            this.telefon1.Name = "telefon1";
            this.telefon1.Size = new System.Drawing.Size(181, 38);
            this.telefon1.TabIndex = 92;
            this.telefon1.Text = "0234-370066";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label34.Location = new System.Drawing.Point(952, 570);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(134, 38);
            this.label34.TabIndex = 91;
            this.label34.Text = "Telefon:";
            // 
            // fax1
            // 
            this.fax1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.fax1.Location = new System.Drawing.Point(1365, 572);
            this.fax1.Name = "fax1";
            this.fax1.Size = new System.Drawing.Size(201, 38);
            this.fax1.TabIndex = 90;
            this.fax1.Text = "0234-370049";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label35.Location = new System.Drawing.Point(1278, 572);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(81, 38);
            this.label35.TabIndex = 89;
            this.label35.Text = "Fax:";
            // 
            // functia1
            // 
            this.functia1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.functia1.Location = new System.Drawing.Point(1610, 747);
            this.functia1.Name = "functia1";
            this.functia1.Size = new System.Drawing.Size(198, 38);
            this.functia1.TabIndex = 102;
            this.functia1.Text = "Sef Serviciu";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label36.Location = new System.Drawing.Point(1488, 750);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(116, 32);
            this.label36.TabIndex = 101;
            this.label36.Text = "Functia:";
            // 
            // reprezentant1
            // 
            this.reprezentant1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.reprezentant1.Location = new System.Drawing.Point(1152, 744);
            this.reprezentant1.Name = "reprezentant1";
            this.reprezentant1.Size = new System.Drawing.Size(331, 38);
            this.reprezentant1.TabIndex = 100;
            this.reprezentant1.Text = "ing. Jitaru Augustin";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label37.Location = new System.Drawing.Point(953, 744);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(193, 32);
            this.label37.TabIndex = 99;
            this.label37.Text = "Reprezentant:";
            // 
            // sucursala1
            // 
            this.sucursala1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.sucursala1.Location = new System.Drawing.Point(1494, 689);
            this.sucursala1.Name = "sucursala1";
            this.sucursala1.Size = new System.Drawing.Size(314, 38);
            this.sucursala1.TabIndex = 98;
            this.sucursala1.Text = "Moinesti";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label38.Location = new System.Drawing.Point(1329, 689);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(159, 32);
            this.label38.TabIndex = 97;
            this.label38.Text = "Sucursala:";
            // 
            // cont1
            // 
            this.cont1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cont1.Location = new System.Drawing.Point(1046, 627);
            this.cont1.Name = "cont1";
            this.cont1.Size = new System.Drawing.Size(677, 38);
            this.cont1.TabIndex = 96;
            this.cont1.Text = "RO22TREZ063502205X005032";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label39.Location = new System.Drawing.Point(953, 630);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(87, 32);
            this.label39.TabIndex = 95;
            this.label39.Text = "Cont:";
            // 
            // deschis1
            // 
            this.deschis1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.deschis1.Location = new System.Drawing.Point(1090, 683);
            this.deschis1.Name = "deschis1";
            this.deschis1.Size = new System.Drawing.Size(232, 38);
            this.deschis1.TabIndex = 94;
            this.deschis1.Text = "Trezoreria";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label40.Location = new System.Drawing.Point(953, 686);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(131, 32);
            this.label40.TabIndex = 93;
            this.label40.Text = "Deschis:";
            // 
            // Vigoare
            // 
            this.Vigoare.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Vigoare.Location = new System.Drawing.Point(1297, 97);
            this.Vigoare.Name = "Vigoare";
            this.Vigoare.Size = new System.Drawing.Size(224, 30);
            this.Vigoare.TabIndex = 104;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label41.Location = new System.Drawing.Point(808, 98);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(473, 29);
            this.label41.TabIndex = 103;
            this.label41.Text = "Data de cand intra contractul in vigoare:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 975);
            this.Controls.Add(this.Vigoare);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.functia1);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.reprezentant1);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.sucursala1);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.cont1);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.deschis1);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.telefon1);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.fax1);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.Coddeindentificarefiscala1);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.Codpostal1);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.strada1);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.Numar1);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.judet1);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.oras1);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.NumeSocietate1);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.Nr);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.functia);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.reprezentat);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.sucursala);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.Cont);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.Deschis);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.CUI);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.telefon);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.NORC);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.etaj);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Ap);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.Bloc);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Scara);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.judet);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Foaie);
            this.Controls.Add(this.Genereaza_contract);
            this.Controls.Add(this.NumeSocietate);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Forma_de_activitate);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Oras);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Strada);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.NumarStrada);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Alege);
            this.Controls.Add(this.Cale);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prototip_jurist";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.afisare_tabel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox Foaie;
        private System.Windows.Forms.Button Genereaza_contract;
        private System.Windows.Forms.TextBox NumeSocietate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Forma_de_activitate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Oras;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Strada;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox NumarStrada;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView afisare_tabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Alege;
        private System.Windows.Forms.TextBox Cale;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox judet;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Bloc;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Scara;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox etaj;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox Ap;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox NORC;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox Cont;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox Deschis;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox CUI;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox telefon;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox sucursala;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox functia;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox reprezentat;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox Nr;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox Data;
        private System.Windows.Forms.Label label8;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox NumeSocietate1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox judet1;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox oras1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox strada1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox Numar1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox Codpostal1;
        private System.Windows.Forms.TextBox Coddeindentificarefiscala1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox telefon1;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox fax1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox functia1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox reprezentant1;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox sucursala1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox cont1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox deschis1;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox Vigoare;
        private System.Windows.Forms.Label label41;
    }
}

