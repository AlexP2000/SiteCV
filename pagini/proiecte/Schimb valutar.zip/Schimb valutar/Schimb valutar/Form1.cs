﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Schimb_valutar
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            comboBox3.Text = " ";
            textBox2.Text = " ";
            comboBox1.Text = " ";
            comboBox2.Text = " ";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
       double inmultire(double banii, double convertor)
        {
            return banii * convertor;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox3.Text = Convert.ToString(comboBox2.SelectedItem);
             

                if (comboBox1.SelectedItem == "EUR" && comboBox2.SelectedItem == "EUR")
                {
                    textBox2.Text = textBox1.Text;
                }
                else if (comboBox1.SelectedItem == "USD" && comboBox2.SelectedItem == "USD")
                {
                    textBox2.Text = textBox1.Text;
                }
                else if (comboBox1.SelectedItem == "GBP" && comboBox2.SelectedItem == "GBP")
                {
                textBox2.Text = textBox1.Text;
                }
                else if (comboBox1.SelectedItem == "RON" && comboBox2.SelectedItem == "RON")
                {
                textBox2.Text = textBox1.Text;
                
                }
                 else if (comboBox1.SelectedItem == "EUR" && comboBox2.SelectedItem == "USD")
                 {
                MessageBox.Show("Va urma");
                 }
               else if (comboBox1.SelectedItem == "EUR" && comboBox2.SelectedItem == "GBP")
               {
                MessageBox.Show("Va urma");
            }
            else if (comboBox1.SelectedItem == "EUR" && comboBox2.SelectedItem == "RON")
            {
                MessageBox.Show("Va urma");
            }
            else if (comboBox1.SelectedItem == "USD" && comboBox2.SelectedItem == "EUR")
            {
                MessageBox.Show("Va urma");
            }
            else if (comboBox1.SelectedItem == "USD" && comboBox2.SelectedItem == "GBP")
            {
                MessageBox.Show("Va urma");
            }
            else if (comboBox1.SelectedItem == "USD" && comboBox2.SelectedItem == "RON")
            {
                MessageBox.Show("Va urma");
            }
            else if (comboBox1.SelectedItem == "GBP" && comboBox2.SelectedItem == "EUR")
            {
                MessageBox.Show("Va urma");
            }
            else if (comboBox1.SelectedItem == "GBP" && comboBox2.SelectedItem == "USD")
            {
                MessageBox.Show("Va urma");
            }
            else if (comboBox1.SelectedItem == "GBP" && comboBox2.SelectedItem == "RON")
            {
                MessageBox.Show("Va urma");
            }
            else if (comboBox1.SelectedItem == "RON" && comboBox2.SelectedItem == "EUR")
            {
                MessageBox.Show("Va urma");
            }
            else if (comboBox1.SelectedItem == "RON" && comboBox2.SelectedItem == "USD")
            {
                MessageBox.Show("Va urma");
            }
            else if (comboBox1.SelectedItem == "Ron" && comboBox2.SelectedItem == "GBP")
            {
                MessageBox.Show("Va urma");
            }
            
        }
    }
}
