﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimplePuzzleGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void shuffleButtons()
        {
            
            
        }

       

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void OnExitClick(object sender, EventArgs e)
        {
            this.Hide();
            Mesaj_de_atentionare r = new Mesaj_de_atentionare();
            r.Show();
        }
         ~Form1()
        {
           
        }

        private void OnMouseHoverExit(object sender, EventArgs e)
        {
            Cursor = Cursors.Hand;
        }

        private void OnMouseLeaveExit(object sender, EventArgs e)
        {
            Cursor = Cursors.Arrow;
        }

        private void buton1_Click(object sender, EventArgs e)
        {
            if(buton2.Text=="")
            {
                buton2.Text = buton1.Text;
                buton1.Text = "";
            }
            if (buton5.Text == "")
            {
                buton5.Text = buton1.Text;
                buton1.Text = "";
            }
        }

        private void buton2_Click(object sender, EventArgs e)
        {
            if (buton1.Text == "")
            {
                buton1.Text = buton2.Text;
                buton2.Text = "";
            }
            if (buton6.Text == "")
            {
                buton6.Text = buton2.Text;
                buton2.Text = "";
            }
            if(buton3.Text == "")
            {
                 buton3.Text = buton2.Text;
                buton2.Text = "";
            }
        }

        private void buton3_Click(object sender, EventArgs e)
        {
            if (buton2.Text == "")
            {
                buton2.Text = buton3.Text;
                buton3.Text = "";
            }
            if (buton7.Text == "")
            {
                buton7.Text = buton3.Text;
                buton3.Text = "";
            }
            if (buton4.Text == "")
            {
                buton4.Text = buton3.Text;
                buton3.Text = "";
            }
        }

        private void buton4_Click(object sender, EventArgs e)
        {
            if (buton3.Text == "")
            {
                buton3.Text = buton4.Text;
                buton4.Text = "";
            }
            if (buton8.Text == "")
            {
                buton8.Text = buton4.Text;
                buton4.Text = "";
            }
        }

        private void buton5_Click(object sender, EventArgs e)
        {
            if (buton1.Text == "")
            {
                buton1.Text = buton5.Text;
                buton5.Text = "";
            }
            if (buton6.Text == "")
            {
                buton6.Text = buton5.Text;
                buton5.Text = "";
            }
            if (buton9.Text == "")
            {
                buton9.Text = buton5.Text;
                buton5.Text = "";
            }
        }

        private void buton6_Click(object sender, EventArgs e)
        {
            if (buton2.Text == "")
            {
                buton2.Text = buton6.Text;
                buton6.Text = "";
            }
            if (buton5.Text == "")
            {
                buton5.Text = buton6.Text;
                buton6.Text = "";
            }
            if (buton10.Text == "")
            {
                buton10.Text = buton6.Text;
                buton6.Text = "";
            }
            if (buton7.Text == "")
            {
                buton7.Text = buton6.Text;
                buton6.Text = "";
            }
        }

        private void buton7_Click(object sender, EventArgs e)
        {
            if (buton3.Text == "")
            {
                buton3.Text = buton7.Text;
                buton7.Text = "";
            }
            if (buton6.Text == "")
            {
                buton6.Text = buton7.Text;
                buton7.Text = "";
            }
            if (buton11.Text == "")
            {
                buton11.Text = buton7.Text;
                buton7.Text = "";
            }
            if (buton8.Text == "")
            {
                buton8.Text = buton7.Text;
                buton7.Text = "";
            }
        }

        private void buton8_Click(object sender, EventArgs e)
        {
            if (buton4.Text == "")
            {
                buton4.Text = buton8.Text;
                buton8.Text = "";
            }
            if (buton7.Text == "")
            {
                buton7.Text = buton8.Text;
                buton8.Text = "";
            }
            if (buton12.Text == "")
            {
                buton12.Text = buton8.Text;
                buton8.Text = "";
            }
        }

        private void buton9_Click(object sender, EventArgs e)
        {
            if (buton5.Text == "")
            {
                buton5.Text = buton9.Text;
                buton9.Text = "";
            }
            if (buton10.Text == "")
            {
                buton10.Text = buton9.Text;
                buton9.Text = "";
            }
        }

        private void buton10_Click(object sender, EventArgs e)
        {
            if (buton9.Text == "")
            {
                buton9.Text = buton10.Text;
                buton10.Text = "";
            }
            if (buton6.Text == "")
            {
                buton6.Text = buton10.Text;
                buton10.Text = "";
            }
            if (buton11.Text == "")
            {
                buton11.Text = buton10.Text;
                buton10.Text = "";
            }
        }

        private void buton11_Click(object sender, EventArgs e)
        {
            if (buton10.Text == "")
            {
                buton10.Text = buton11.Text;
                buton11.Text = "";
            }
            if (buton7.Text == "")
            {
                buton7.Text = buton11.Text;
                buton11.Text = "";
            }
            if (buton12.Text == "")
            {
                buton12.Text = buton11.Text;
                buton11.Text = "";
            }
        }

        private void buton12_Click(object sender, EventArgs e)
        {
            if (buton8.Text == "")
            {
                buton8.Text = buton12.Text;
                buton12.Text = "";
            }
            if (buton11.Text == "")
            {
                buton11.Text = buton12.Text;
                buton12.Text = "";
            }
        }
    }
}
