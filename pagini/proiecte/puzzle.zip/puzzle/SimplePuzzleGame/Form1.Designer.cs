﻿namespace SimplePuzzleGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.buton10 = new System.Windows.Forms.Button();
            this.buton9 = new System.Windows.Forms.Button();
            this.buton8 = new System.Windows.Forms.Button();
            this.buton7 = new System.Windows.Forms.Button();
            this.buton6 = new System.Windows.Forms.Button();
            this.buton5 = new System.Windows.Forms.Button();
            this.buton4 = new System.Windows.Forms.Button();
            this.buton3 = new System.Windows.Forms.Button();
            this.buton2 = new System.Windows.Forms.Button();
            this.buton1 = new System.Windows.Forms.Button();
            this.buton12 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.PictureBox();
            this.buton11 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Exit)).BeginInit();
            this.SuspendLayout();
            // 
            // buton10
            // 
            this.buton10.BackColor = System.Drawing.Color.Transparent;
            this.buton10.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton10.Location = new System.Drawing.Point(227, 363);
            this.buton10.Name = "buton10";
            this.buton10.Size = new System.Drawing.Size(160, 83);
            this.buton10.TabIndex = 31;
            this.buton10.Text = "10";
            this.buton10.UseVisualStyleBackColor = false;
            this.buton10.Click += new System.EventHandler(this.buton10_Click);
            // 
            // buton9
            // 
            this.buton9.BackColor = System.Drawing.Color.Transparent;
            this.buton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton9.Location = new System.Drawing.Point(42, 363);
            this.buton9.Name = "buton9";
            this.buton9.Size = new System.Drawing.Size(160, 83);
            this.buton9.TabIndex = 30;
            this.buton9.Text = "9";
            this.buton9.UseVisualStyleBackColor = false;
            this.buton9.Click += new System.EventHandler(this.buton9_Click);
            // 
            // buton8
            // 
            this.buton8.BackColor = System.Drawing.Color.Transparent;
            this.buton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton8.Location = new System.Drawing.Point(610, 253);
            this.buton8.Name = "buton8";
            this.buton8.Size = new System.Drawing.Size(160, 83);
            this.buton8.TabIndex = 29;
            this.buton8.Text = "8";
            this.buton8.UseVisualStyleBackColor = false;
            this.buton8.Click += new System.EventHandler(this.buton8_Click);
            // 
            // buton7
            // 
            this.buton7.BackColor = System.Drawing.Color.Transparent;
            this.buton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton7.Location = new System.Drawing.Point(421, 253);
            this.buton7.Name = "buton7";
            this.buton7.Size = new System.Drawing.Size(160, 83);
            this.buton7.TabIndex = 28;
            this.buton7.Text = "7";
            this.buton7.UseVisualStyleBackColor = false;
            this.buton7.Click += new System.EventHandler(this.buton7_Click);
            // 
            // buton6
            // 
            this.buton6.BackColor = System.Drawing.Color.Transparent;
            this.buton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton6.Location = new System.Drawing.Point(227, 253);
            this.buton6.Name = "buton6";
            this.buton6.Size = new System.Drawing.Size(160, 83);
            this.buton6.TabIndex = 27;
            this.buton6.Text = "6";
            this.buton6.UseVisualStyleBackColor = false;
            this.buton6.Click += new System.EventHandler(this.buton6_Click);
            // 
            // buton5
            // 
            this.buton5.BackColor = System.Drawing.Color.Transparent;
            this.buton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton5.Location = new System.Drawing.Point(42, 253);
            this.buton5.Name = "buton5";
            this.buton5.Size = new System.Drawing.Size(160, 83);
            this.buton5.TabIndex = 26;
            this.buton5.Text = "5";
            this.buton5.UseVisualStyleBackColor = false;
            this.buton5.Click += new System.EventHandler(this.buton5_Click);
            // 
            // buton4
            // 
            this.buton4.BackColor = System.Drawing.Color.Transparent;
            this.buton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton4.Location = new System.Drawing.Point(610, 150);
            this.buton4.Name = "buton4";
            this.buton4.Size = new System.Drawing.Size(160, 83);
            this.buton4.TabIndex = 25;
            this.buton4.Text = "4";
            this.buton4.UseVisualStyleBackColor = false;
            this.buton4.Click += new System.EventHandler(this.buton4_Click);
            // 
            // buton3
            // 
            this.buton3.BackColor = System.Drawing.Color.Transparent;
            this.buton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton3.Location = new System.Drawing.Point(421, 150);
            this.buton3.Name = "buton3";
            this.buton3.Size = new System.Drawing.Size(160, 83);
            this.buton3.TabIndex = 24;
            this.buton3.Text = "3";
            this.buton3.UseVisualStyleBackColor = false;
            this.buton3.Click += new System.EventHandler(this.buton3_Click);
            // 
            // buton2
            // 
            this.buton2.BackColor = System.Drawing.Color.Transparent;
            this.buton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton2.Location = new System.Drawing.Point(227, 150);
            this.buton2.Name = "buton2";
            this.buton2.Size = new System.Drawing.Size(160, 83);
            this.buton2.TabIndex = 23;
            this.buton2.Text = "2";
            this.buton2.UseVisualStyleBackColor = false;
            this.buton2.Click += new System.EventHandler(this.buton2_Click);
            // 
            // buton1
            // 
            this.buton1.BackColor = System.Drawing.Color.Transparent;
            this.buton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton1.Location = new System.Drawing.Point(42, 150);
            this.buton1.Name = "buton1";
            this.buton1.Size = new System.Drawing.Size(160, 83);
            this.buton1.TabIndex = 22;
            this.buton1.Text = "1";
            this.buton1.UseVisualStyleBackColor = false;
            this.buton1.Click += new System.EventHandler(this.buton1_Click);
            // 
            // buton12
            // 
            this.buton12.BackColor = System.Drawing.Color.Transparent;
            this.buton12.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton12.Location = new System.Drawing.Point(610, 363);
            this.buton12.Name = "buton12";
            this.buton12.Size = new System.Drawing.Size(160, 83);
            this.buton12.TabIndex = 21;
            this.buton12.UseVisualStyleBackColor = false;
            this.buton12.Click += new System.EventHandler(this.buton11_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(153, 132);
            this.pictureBox1.TabIndex = 32;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mistral", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(171, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 76);
            this.label1.TabIndex = 33;
            this.label1.Text = "Puzzle";
            // 
            // Exit
            // 
            this.Exit.Image = ((System.Drawing.Image)(resources.GetObject("Exit.Image")));
            this.Exit.Location = new System.Drawing.Point(666, 1);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(115, 119);
            this.Exit.TabIndex = 34;
            this.Exit.TabStop = false;
            this.Exit.Click += new System.EventHandler(this.OnExitClick);
            this.Exit.MouseLeave += new System.EventHandler(this.OnMouseLeaveExit);
            this.Exit.MouseHover += new System.EventHandler(this.OnMouseHoverExit);
            // 
            // buton11
            // 
            this.buton11.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buton11.Location = new System.Drawing.Point(421, 363);
            this.buton11.Name = "buton11";
            this.buton11.Size = new System.Drawing.Size(160, 83);
            this.buton11.TabIndex = 35;
            this.buton11.Text = "11";
            this.buton11.UseVisualStyleBackColor = true;
            this.buton11.Click += new System.EventHandler(this.buton12_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(782, 458);
            this.Controls.Add(this.buton11);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buton10);
            this.Controls.Add(this.buton9);
            this.Controls.Add(this.buton8);
            this.Controls.Add(this.buton7);
            this.Controls.Add(this.buton6);
            this.Controls.Add(this.buton5);
            this.Controls.Add(this.buton4);
            this.Controls.Add(this.buton3);
            this.Controls.Add(this.buton2);
            this.Controls.Add(this.buton1);
            this.Controls.Add(this.buton12);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Puzzle";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Exit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buton10;
        private System.Windows.Forms.Button buton9;
        private System.Windows.Forms.Button buton8;
        private System.Windows.Forms.Button buton7;
        private System.Windows.Forms.Button buton6;
        private System.Windows.Forms.Button buton5;
        private System.Windows.Forms.Button buton4;
        private System.Windows.Forms.Button buton3;
        private System.Windows.Forms.Button buton2;
        private System.Windows.Forms.Button buton1;
        private System.Windows.Forms.Button buton12;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Exit;
        private System.Windows.Forms.Button buton11;
    }
}

